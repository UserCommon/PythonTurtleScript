import turtle


class Executor:
    def __init__(self, turtles, curr_turtle_index):
        curr_turtle = turtles[curr_turtle_index]
        self.commands = {"": curr_turtle.do_nothing, "S": self.change_turtle, "F": turtles}

    def change_turtle(self, turtle_index) -> None:
        USING_TURTLE_NOW = turtle_index


class Command:
    def __init__(self, info: str) -> None:
        self.info = info


class Reader:
    def __init__(self, name) -> None:
        self.file = open(name, "r")

    def read(self) -> list[list[str]]:
        return list(map(lambda x: list(x.replace("\n", "")), self.file.readlines()))


class Interpreter(Reader, Executor):
    def __init__(self, name, turtle, curr_turtle_index) -> None:
        Reader.__init__(self, name)
        Executor.__init__(self, turtle, curr_turtle_index)
        self.commands = []
        self.turtle = turtle 
    
    def make_work(self):
        parsed_file = self.read()

        for element in parsed_file:
            for word in element:
                if 



class Turtle:

    def __init__(self) -> None:
        self.turtle = turtle.Turtle()

    def event_cycle(self) -> None:
        while True:
            pass

    def move_forward(self, quantity) -> None:
        self.turtle.forward(quantity)

    def move_backward(self, quantity) -> None:
        self.turtle.backward(quantity)

    def move_left(self, quantity) -> None:
        self.turtle.left(quantity)

    def move_right(self, quantity) -> None:
        self.turtle.right(quantity)

    @staticmethod
    def do_nothing() -> None:
        return None



def main():
    USING_TURTLE_NOW = 0
    GLOBAL_TURTLES_STORAGE = [Turtle()] 
    interpreter = Interpreter("script.do", GLOBAL_TURTLES_STORAGE[USING_TURTLE_NOW])

    

