from poetry_outside_lang.main import turtle

import turtle


class SETTING:
    GLOB_TURTLES = [Turtle()]
